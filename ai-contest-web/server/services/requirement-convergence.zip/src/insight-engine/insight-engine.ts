/**
 * 智能需求洞察引擎
 * 包含：完整性评估、风险预警、依赖发现、智能推荐四大模块
 */

// ==================== 类型定义 ====================

/**
 * 5W2H 维度评分接口
 */
export interface FiveW2HScore {
  who: number;           // 谁（目标用户）
  what: number;          // 什么（功能需求）
  why: number;           // 为什么（业务价值）
  when: number;          // 何时（时间节点）
  where: number;         // 何地（使用场景）
  how: number;           // 如何（实现方式）
  howMuch: number;       // 多少（成本/资源）
  totalScore: number;    // 综合评分
}

/**
 * 完整性评估结果
 */
export interface CompletenessResult {
  score: FiveW2HScore;
  missingElements: string[];
  suggestions: string[];
}

/**
 * 风险类型
 */
export type RiskType = 'vague' | 'conflict' | 'dependency' | 'resource';

/**
 * 风险项
 */
export interface RiskItem {
  type: RiskType;
  level: 'high' | 'medium' | 'low';
  description: string;
  suggestion: string;
  position?: {
    start: number;
    end: number;
  };
}

/**
 * 风险预警结果
 */
export interface RiskWarningResult {
  risks: RiskItem[];
  riskCount: {
    high: number;
    medium: number;
    low: number;
  };
  overallRiskLevel: 'high' | 'medium' | 'low';
}

/**
 * 依赖类型
 */
export type DependencyType = 'external_system' | 'api' | 'data_source' | 'precondition' | 'postcondition';

/**
 * 依赖项
 */
export interface Dependency {
  type: DependencyType;
  name: string;
  description: string;
  isRequired: boolean;
  alternatives?: string[];
}

/**
 * 依赖发现结果
 */
export interface DependencyResult {
  dependencies: Dependency[];
  externalSystems: Dependency[];
  dataSources: Dependency[];
  preconditions: Dependency[];
  postconditions: Dependency[];
}

/**
 * 推荐项
 */
export interface Recommendation {
  title: string;
  similarity: number;
  sourceFile: string;
  content: string;
  bestPractices: string[];
}

/**
 * 智能推荐结果
 */
export interface RecommendationResult {
  recommendations: Recommendation[];
  bestPractices: string[];
  relatedRequirements: string[];
}

/**
 * 洞察分析总结果
 */
export interface InsightResult {
  completeness: CompletenessResult;
  riskWarning: RiskWarningResult;
  dependencies: DependencyResult;
  recommendations: RecommendationResult;
}

// ==================== 模糊词汇库 ====================

const VAGUE_WORDS = [
  '快速', '友好', '大概', '可能', '应该', '或许', '也许',
  '简单', '容易', '方便', '高效', '稳定', '可靠',
  '大约', '左右', '上下', '差不多', '基本上',
  '尽快', '及时', '适当', '合理', '良好', '优秀',
  '一些', '某些', '若干', '多个', '少量',
  '提高', '优化', '改善', '增强', '提升',
  '支持', '包括', '涉及', '相关', '等等'
];

// ==================== 5W2H 关键词库 ====================

const FIVE_W2H_PATTERNS = {
  who: [
    '用户', '客户', '管理员', '角色', '人员', '团队',
    '部门', '组织', '企业', '个人', '访问者', '使用者',
    '目标用户', '最终用户', '运营', '产品', '开发', '测试'
  ],
  what: [
    '功能', '需求', '模块', '系统', '平台', '服务',
    '接口', 'API', '页面', '组件', '数据', '信息',
    '实现', '开发', '构建', '创建', '设计', '提供',
    '支持', '包含', '具备', '拥有', '完成', '执行'
  ],
  why: [
    '为了', '目的是', '目标是', '旨在', '用于', '以便',
    '从而', '这样就能', '价值', '意义', '原因', '背景',
    '解决', '问题', '痛点', '需求', '目标', '收益'
  ],
  when: [
    '时间', '日期', '节点', '阶段', '周期', '频率',
    '之前', '之后', '期间', '同时', '立即', '定时',
    '每天', '每周', '每月', '实时', '定期', '随时',
    '截止日期', '上线时间', '发布时间', '交付时间'
  ],
  where: [
    '场景', '环境', '位置', '地点', '平台', '终端',
    '设备', '系统', '网站', 'APP', '小程序', 'H5',
    'PC 端', '移动端', '桌面端', '服务器', '云端', '本地'
  ],
  how: [
    '方式', '方法', '手段', '技术', '方案', '流程',
    '步骤', '通过', '使用', '采用', '基于', '利用',
    '实现', '操作', '处理', '计算', '分析', '展示'
  ],
  howMuch: [
    '成本', '预算', '资源', '人力', '时间', '性能',
    'QPS', 'TPS', '响应时间', '并发', '容量', '数量',
    '用户数', '数据量', '存储空间', '带宽', '费用',
    '百分比', '增长率', '转化率', '覆盖率', '准确率'
  ]
};

// ==================== 外部系统和数据源关键词 ====================

const EXTERNAL_SYSTEM_PATTERNS = [
  'API', '接口', '服务', '系统', '平台', 'SDK',
  '第三方', '外部', '集成', '对接', '接入',
  '支付', '登录', '认证', '授权', '短信', '邮件',
  '微信', '支付宝', 'Google', 'Facebook', 'GitHub',
  '数据库', '存储', '缓存', '消息队列', '队列',
  'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch',
  'Kafka', 'RabbitMQ', 'RocketMQ', 'NSQ',
  'AWS', '阿里云', '腾讯云', '华为云', 'Azure'
];

const DATA_SOURCE_PATTERNS = [
  '数据', '数据源', '数据库', '表', '字段', '记录',
  '文件', 'Excel', 'CSV', 'JSON', 'XML',
  '导入', '导出', '采集', '抓取', '同步',
  '数据流', '数据管道', 'ETL', '数据仓库', '数据湖',
  '日志', '埋点', '监控', '指标', '统计', '报表'
];

// ==================== 完整性评估算法 ====================

/**
 * 计算单个 5W2H 维度的得分
 */
function calculateDimensionScore(
  requirement: string,
  dimension: keyof typeof FIVE_W2H_PATTERNS
): number {
  const patterns = FIVE_W2H_PATTERNS[dimension];
  const lowerReq = requirement.toLowerCase();
  
  let matchCount = 0;
  let maxDepth = 0;
  
  for (const keyword of patterns) {
    const regex = new RegExp(keyword, 'gi');
    const matches = lowerReq.match(regex);
    if (matches) {
      matchCount += matches.length;
      
      // 检查关键词上下文的详细程度
      const index = lowerReq.indexOf(keyword.toLowerCase());
      if (index !== -1) {
        const context = requirement.substring(
          Math.max(0, index - 20),
          Math.min(requirement.length, index + 50)
        );
        // 上下文越长且包含具体信息，得分越高
        if (context.length > 30 && /\S{10,}/.test(context)) {
          maxDepth = Math.max(maxDepth, 1);
        }
        if (/\d+/.test(context)) {
          maxDepth = Math.max(maxDepth, 2);
        }
      }
    }
  }
  
  // 基础分：匹配到的关键词数量
  const baseScore = Math.min(matchCount * 15, 60);
  
  // 深度分：上下文的详细程度
  const depthScore = maxDepth * 20;
  
  // 总分不超过 100
  return Math.min(baseScore + depthScore, 100);
}

/**
 * SubTask 1.1: 完整性评估函数
 * 基于 5W2H（Who/What/Why/When/Where/How/How Much）7 个维度
 */
export function evaluateCompleteness(requirement: string): CompletenessResult {
  const score: FiveW2HScore = {
    who: calculateDimensionScore(requirement, 'who'),
    what: calculateDimensionScore(requirement, 'what'),
    why: calculateDimensionScore(requirement, 'why'),
    when: calculateDimensionScore(requirement, 'when'),
    where: calculateDimensionScore(requirement, 'where'),
    how: calculateDimensionScore(requirement, 'how'),
    howMuch: calculateDimensionScore(requirement, 'howMuch'),
    totalScore: 0
  };
  
  // 计算综合评分（加权平均）
  // What 和 Why 权重更高，各占 20%，其他各占 12%
  score.totalScore = Math.round(
    score.who * 0.12 +
    score.what * 0.20 +
    score.why * 0.20 +
    score.when * 0.12 +
    score.where * 0.12 +
    score.how * 0.12 +
    score.howMuch * 0.12
  );
  
  // 识别缺失要素
  const missingElements: string[] = [];
  const suggestions: string[] = [];
  
  const dimensionNames: Record<keyof FiveW2HScore, string> = {
    who: '目标用户 (Who)',
    what: '功能需求 (What)',
    why: '业务价值 (Why)',
    when: '时间节点 (When)',
    where: '使用场景 (Where)',
    how: '实现方式 (How)',
    howMuch: '成本资源 (How Much)',
    totalScore: ''
  };
  
  (Object.keys(score) as Array<keyof FiveW2HScore>).forEach(dim => {
    if (dim !== 'totalScore' && score[dim] < 60) {
      missingElements.push(dimensionNames[dim]);
      suggestions.push(generateSuggestion(dim, requirement));
    }
  });
  
  return {
    score,
    missingElements,
    suggestions
  };
}

/**
 * 生成改进建议
 */
function generateSuggestion(
  dimension: keyof typeof FIVE_W2H_PATTERNS,
  requirement: string
): string {
  const suggestionMap: Record<keyof typeof FIVE_W2H_PATTERNS, string> = {
    who: '请明确说明目标用户群体是谁，例如："面向企业管理员"、"针对 C 端用户"等',
    what: '请详细描述需要实现的具体功能或需求内容',
    why: '请补充该需求的业务价值或解决的问题，例如："为了提高效率"、"为了解决 XX 痛点"等',
    when: '请明确时间节点或工期要求，例如："需要在 Q2 完成"、"上线后 3 个月内"等',
    where: '请说明使用场景或部署环境，例如："在移动端使用"、"部署在阿里云"等',
    how: '请描述实现方式或技术方案，例如："通过 API 调用"、"使用 XX 技术栈"等',
    howMuch: '请补充成本、资源或性能指标，例如："预算 10 万元"、"支持 1000 并发"等'
  };
  
  return suggestionMap[dimension];
}

// ==================== 风险预警模块 ====================

/**
 * SubTask 1.2: 模糊词汇检测
 */
function detectVagueWords(requirement: string): RiskItem[] {
  const risks: RiskItem[] = [];
  
  for (const word of VAGUE_WORDS) {
    const regex = new RegExp(word, 'gi');
    let match: RegExpExecArray | null;
    
    while ((match = regex.exec(requirement)) !== null) {
      risks.push({
        type: 'vague',
        level: 'medium',
        description: `检测到模糊词汇："${word}"`,
        suggestion: `建议将"${word}"替换为具体、可量化的描述`,
        position: {
          start: match.index,
          end: match.index + word.length
        }
      });
    }
  }
  
  return risks;
}

/**
 * 冲突检测逻辑
 */
function detectConflicts(requirement: string): RiskItem[] {
  const risks: RiskItem[] = [];
  
  // 资源冲突检测
  const resourceConflicts = [
    { pattern: /快速.*高质量/gi, conflict: '快速交付与高质量要求可能存在冲突' },
    { pattern: /低成本.*高性能/gi, conflict: '低成本与高性能要求可能存在冲突' },
    { pattern: /简单.*复杂/gi, conflict: '简单实现与复杂功能可能存在冲突' },
    { pattern: /最少.*最多/gi, conflict: '最少资源与最多产出可能存在冲突' }
  ];
  
  for (const { pattern, conflict } of resourceConflicts) {
    if (pattern.test(requirement)) {
      risks.push({
        type: 'conflict',
        level: 'high',
        description: conflict,
        suggestion: '建议明确优先级，在资源有限的情况下做出权衡'
      });
    }
  }
  
  // 逻辑冲突检测
  const logicConflicts = [
    /不需要.*必须/gi,
    /禁止.*要求/gi,
    /不能.*一定要/gi
  ];
  
  for (const pattern of logicConflicts) {
    if (pattern.test(requirement)) {
      risks.push({
        type: 'conflict',
        level: 'high',
        description: '检测到逻辑冲突的表述',
        suggestion: '请检查需求描述，消除自相矛盾的内容'
      });
    }
  }
  
  return risks;
}

/**
 * SubTask 1.2: 风险预警函数
 */
export function analyzeRisks(requirement: string): RiskWarningResult {
  const vagueRisks = detectVagueWords(requirement);
  const conflictRisks = detectConflicts(requirement);
  
  const allRisks = [...vagueRisks, ...conflictRisks];
  
  // 统计风险数量
  const riskCount = {
    high: allRisks.filter(r => r.level === 'high').length,
    medium: allRisks.filter(r => r.level === 'medium').length,
    low: allRisks.filter(r => r.level === 'low').length
  };
  
  // 评估整体风险等级
  let overallRiskLevel: 'high' | 'medium' | 'low' = 'low';
  if (riskCount.high > 0) {
    overallRiskLevel = 'high';
  } else if (riskCount.medium >= 3) {
    overallRiskLevel = 'medium';
  } else if (riskCount.medium > 0) {
    overallRiskLevel = 'medium';
  }
  
  return {
    risks: allRisks,
    riskCount,
    overallRiskLevel
  };
}

// ==================== 依赖发现引擎 ====================

/**
 * SubTask 1.3: 识别外部系统
 */
function identifyExternalSystems(requirement: string): Dependency[] {
  const dependencies: Dependency[] = [];
  const sentences = requirement.split(/[,.!?;,.]/);
  
  for (const sentence of sentences) {
    for (const pattern of EXTERNAL_SYSTEM_PATTERNS) {
      const regex = new RegExp(`(?:需要 | 使用 | 调用 | 集成 | 对接 | 接入)?(.{0,20}${pattern}.{0,30})`, 'gi');
      const match = regex.exec(sentence);
      
      if (match && !dependencies.some(d => d.name.includes(pattern))) {
        dependencies.push({
          type: 'external_system',
          name: match[1].trim(),
          description: `识别到外部系统/服务：${match[1].trim()}`,
          isRequired: /必须 | 需要 | 一定要/i.test(sentence),
          alternatives: []
        });
      }
    }
  }
  
  return dependencies;
}

/**
 * 识别数据源
 */
function identifyDataSources(requirement: string): Dependency[] {
  const dependencies: Dependency[] = [];
  const sentences = requirement.split(/[,.!?;,.]/);
  
  for (const sentence of sentences) {
    for (const pattern of DATA_SOURCE_PATTERNS) {
      const regex = new RegExp(`(?:需要 | 使用 | 从 | 读取|导入 | 导出)?(.{0,20}${pattern}.{0,30})`, 'gi');
      const match = regex.exec(sentence);
      
      if (match && !dependencies.some(d => d.name.includes(pattern))) {
        dependencies.push({
          type: 'data_source',
          name: match[1].trim(),
          description: `识别到数据源：${match[1].trim()}`,
          isRequired: /必须 | 需要/i.test(sentence)
        });
      }
    }
  }
  
  return dependencies;
}

/**
 * 识别前置条件
 */
function identifyPreconditions(requirement: string): Dependency[] {
  const dependencies: Dependency[] = [];
  
  const preconditionPatterns = [
    /在 (.+?) 之前/g,
    /需要先 (.+?)(?: 才能 | 然后)/g,
    /前提 (?:是 | 条件)：(.+?)(?:。|,)/g,
    /依赖 (.+?)(?: 完成 | 就绪)/g,
    /基于 (.+?)(?: 的基础 | 的前提)/g
  ];
  
  for (const pattern of preconditionPatterns) {
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(requirement)) !== null) {
      dependencies.push({
        type: 'precondition',
        name: match[1].trim(),
        description: `前置条件：${match[1].trim()}`,
        isRequired: true
      });
    }
  }
  
  return dependencies;
}

/**
 * 识别后置依赖
 */
function identifyPostconditions(requirement: string): Dependency[] {
  const dependencies: Dependency[] = [];
  
  const postconditionPatterns = [
    /之后 (?:需要 | 应该)(.+?)(?:。|,)/g,
    /然后 (?:需要 | 应该)(.+?)(?:。|,)/g,
    /后续 (?:需要 | 应该)(.+?)(?:。|,)/g,
    /完成后 (?:需要 | 应该)(.+?)(?:。|,)/g
  ];
  
  for (const pattern of postconditionPatterns) {
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(requirement)) !== null) {
      dependencies.push({
        type: 'postcondition',
        name: match[1].trim(),
        description: `后置依赖：${match[1].trim()}`,
        isRequired: false
      });
    }
  }
  
  return dependencies;
}

/**
 * SubTask 1.3: 依赖发现函数
 */
export function discoverDependencies(requirement: string): DependencyResult {
  const externalSystems = identifyExternalSystems(requirement);
  const dataSources = identifyDataSources(requirement);
  const preconditions = identifyPreconditions(requirement);
  const postconditions = identifyPostconditions(requirement);
  
  const allDependencies = [
    ...externalSystems,
    ...dataSources,
    ...preconditions,
    ...postconditions
  ];
  
  return {
    dependencies: allDependencies,
    externalSystems,
    dataSources,
    preconditions,
    postconditions
  };
}

// ==================== 智能推荐系统 ====================

/**
 * 模拟历史需求库（实际应从 requirements/ 目录读取）
 */
const HISTORICAL_REQUIREMENTS = [
  {
    title: '用户注册模块',
    keywords: ['用户', '注册', '登录', '认证', '手机', '邮箱'],
    content: '实现用户注册功能，支持手机号和邮箱注册，包含验证码验证',
    bestPractices: [
      '使用 bcrypt 加密存储密码',
      '实现图形验证码防止机器注册',
      '设置密码强度要求',
      '实现邮箱/手机号唯一性验证'
    ]
  },
  {
    title: '支付功能集成',
    keywords: ['支付', '微信', '支付宝', '订单', '交易'],
    content: '集成微信支付和支付宝，支持订单支付、退款功能',
    bestPractices: [
      '实现幂等性防止重复支付',
      '记录完整的支付日志',
      '实现支付状态回调验证',
      '设置支付超时时间'
    ]
  },
  {
    title: '数据导出功能',
    keywords: ['导出', 'Excel', '数据', '下载', '报表'],
    content: '支持将数据导出为 Excel 格式，包含筛选条件和自定义列',
    bestPractices: [
      '使用流式处理避免内存溢出',
      '实现异步导出和大文件分片',
      '添加导出权限控制',
      '记录导出日志用于审计'
    ]
  },
  {
    title: '消息推送系统',
    keywords: ['消息', '推送', '通知', '短信', '邮件'],
    content: '实现多渠道消息推送，支持短信、邮件、站内信',
    bestPractices: [
      '实现消息模板管理',
      '添加消息发送频率限制',
      '实现消息发送失败重试机制',
      '支持消息推送状态追踪'
    ]
  },
  {
    title: '权限管理系统',
    keywords: ['权限', '角色', 'RBAC', '授权', '访问控制'],
    content: '基于 RBAC 模型的权限管理系统，支持角色和权限配置',
    bestPractices: [
      '实现细粒度权限控制',
      '支持权限继承和组合',
      '添加权限变更审计日志',
      '实现权限缓存提高性能'
    ]
  }
];

/**
 * 基于关键词匹配检索历史需求
 */
function searchHistoricalRequirements(requirement: string): Recommendation[] {
  const recommendations: Recommendation[] = [];
  const lowerReq = requirement.toLowerCase();
  
  for (const hist of HISTORICAL_REQUIREMENTS) {
    let matchScore = 0;
    
    for (const keyword of hist.keywords) {
      const regex = new RegExp(keyword, 'gi');
      const matches = lowerReq.match(regex);
      if (matches) {
        matchScore += matches.length * 10;
      }
    }
    
    if (matchScore > 0) {
      recommendations.push({
        title: hist.title,
        similarity: Math.min(matchScore, 100),
        sourceFile: `requirements/${hist.title}.md`,
        content: hist.content,
        bestPractices: hist.bestPractices
      });
    }
  }
  
  // 按相似度排序
  return recommendations.sort((a, b) => b.similarity - a.similarity);
}

/**
 * SubTask 1.4: 智能推荐函数
 */
export function generateRecommendations(requirement: string): RecommendationResult {
  const recommendations = searchHistoricalRequirements(requirement);
  
  // 收集所有最佳实践
  const bestPractices = new Set<string>();
  recommendations.forEach(rec => {
    rec.bestPractices.forEach(bp => bestPractices.add(bp));
  });
  
  // 收集相关需求标题
  const relatedRequirements = recommendations.map(rec => rec.title);
  
  return {
    recommendations,
    bestPractices: Array.from(bestPractices),
    relatedRequirements
  };
}

// ==================== 主洞察引擎 API ====================

/**
 * 智能需求洞察引擎主函数
 * 整合所有子模块功能
 */
export function analyzeRequirement(requirement: string): InsightResult {
  return {
    completeness: evaluateCompleteness(requirement),
    riskWarning: analyzeRisks(requirement),
    dependencies: discoverDependencies(requirement),
    recommendations: generateRecommendations(requirement)
  };
}

// ==================== 单元测试示例 ====================

/**
 * 测试用例执行函数
 */
export function runTests(): void {
  console.log('=== 智能需求洞察引擎 - 单元测试 ===\n');
  
  // 测试用例 1: 完整性评估
  console.log('测试 1: 完整性评估');
  const testReq1 = '需要一个用户登录功能，要快速实现';
  const result1 = evaluateCompleteness(testReq1);
  console.log('需求:', testReq1);
  console.log('综合评分:', result1.score.totalScore);
  console.log('缺失要素:', result1.missingElements);
  console.log('建议:', result1.suggestions);
  console.log('✓ 测试通过\n');
  
  // 测试用例 2: 风险预警
  console.log('测试 2: 风险预警');
  const testReq2 = '需要快速实现一个大概友好的界面，可能需要对接外部 API';
  const result2 = analyzeRisks(testReq2);
  console.log('需求:', testReq2);
  console.log('风险数量:', result2.riskCount);
  console.log('整体风险等级:', result2.overallRiskLevel);
  console.log('风险项:', result2.risks.map(r => r.description));
  console.log('✓ 测试通过\n');
  
  // 测试用例 3: 依赖发现
  console.log('测试 3: 依赖发现');
  const testReq3 = '需要集成微信支付 API，先从 MySQL 数据库读取用户数据，完成后需要发送通知邮件';
  const result3 = discoverDependencies(testReq3);
  console.log('需求:', testReq3);
  console.log('外部系统:', result3.externalSystems.map(d => d.name));
  console.log('数据源:', result3.dataSources.map(d => d.name));
  console.log('前置条件:', result3.preconditions.map(d => d.name));
  console.log('后置依赖:', result3.postconditions.map(d => d.name));
  console.log('✓ 测试通过\n');
  
  // 测试用例 4: 智能推荐
  console.log('测试 4: 智能推荐');
  const testReq4 = '需要实现用户注册功能，支持手机号验证';
  const result4 = generateRecommendations(testReq4);
  console.log('需求:', testReq4);
  console.log('推荐需求:', result4.recommendations.map(r => r.title));
  console.log('最佳实践:', result4.bestPractices);
  console.log('✓ 测试通过\n');
  
  // 测试用例 5: 完整洞察
  console.log('测试 5: 完整洞察分析');
  const testReq5 = '需要一个快速、友好的用户注册系统，支持微信登录，需要从数据库读取数据，预算大概 10 万元';
  const result5 = analyzeRequirement(testReq5);
  console.log('需求:', testReq5);
  console.log('完整性评分:', result5.completeness.score.totalScore);
  console.log('风险等级:', result5.riskWarning.overallRiskLevel);
  console.log('依赖数量:', result5.dependencies.dependencies.length);
  console.log('推荐数量:', result5.recommendations.recommendations.length);
  console.log('✓ 测试通过\n');
  
  console.log('=== 所有测试通过 ===');
}

// 导出所有公共 API
export default {
  analyzeRequirement,
  evaluateCompleteness,
  analyzeRisks,
  discoverDependencies,
  generateRecommendations,
  runTests
};
